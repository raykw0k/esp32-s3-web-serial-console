#!/bin/bash
cd "$(dirname "$0")" || exit 1
echo "Factory install for ESP32-S3 N16R8. This clears saved Wi-Fi, Tailscale and console settings."
read -r -p "Type FLASH to continue: " answer
[[ "$answer" == FLASH ]] || exit 0
case "$(uname -m)" in
  arm64) tool=tools/espflash-arm64 ;;
  x86_64) tool=tools/espflash-x64 ;;
  *) echo "Unsupported Mac architecture."; exit 1 ;;
esac
"$tool" write-bin --skip-update-check --chip esp32s3 --confirm-port 0x0 firmware.bin
result=$?
if [[ $result == 0 ]]; then echo "Done. Join raykwok-rmt-console to configure the board."; else echo "Flash failed. See README.txt and retry."; fi
read -r -p "Press Return to close."
exit "$result"
