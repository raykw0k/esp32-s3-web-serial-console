#include "console.h"
#include <string.h>
#include "lwip/sockets.h"
#include "lwip/inet.h"

#define ASSET(name,link) \
    extern const char name##_start[] asm("_binary_" link "_start"); \
    extern const char name##_end[] asm("_binary_" link "_end")
ASSET(setup,"setup_html");
ASSET(terminal,"terminal_html");
ASSET(style,"style_css");
ASSET(xterm,"xterm_js_gz");
ASSET(xcss,"xterm_css_gz");
#define SEND(name,mime) (httpd_resp_set_type(req,mime), httpd_resp_send(req,name##_start,name##_end-name##_start))

static uint32_t local_address(int fd) {
    struct sockaddr_storage addr;
    socklen_t size = sizeof(addr);
    if (getsockname(fd,(struct sockaddr *)&addr,&size)) return 0;
    if (addr.ss_family == AF_INET) return ntohl(((struct sockaddr_in *)&addr)->sin_addr.s_addr);
#if CONFIG_LWIP_IPV6
    if (addr.ss_family == AF_INET6) {
        struct in6_addr *ip = &((struct sockaddr_in6 *)&addr)->sin6_addr;
        uint32_t v4;
        if (IN6_IS_ADDR_V4MAPPED(ip)) {
            memcpy(&v4, ip->s6_addr + 12, 4);
            return ntohl(v4);
        }
    }
#endif
    return 0;
}

static const char *field(cJSON *json, const char *key) {
    cJSON *item = cJSON_GetObjectItemCaseSensitive(json, key);
    return cJSON_IsString(item) ? item->valuestring : NULL;
}
static esp_err_t provision(httpd_req_t *req, char *body) {
    cJSON *json = cJSON_Parse(body);
    const char *ssid = field(json,"ssid"), *pass = field(json,"password"), *key = field(json,"key");
    esp_err_t err = ESP_ERR_INVALID_ARG;
    cJSON *vpn = cJSON_GetObjectItemCaseSensitive(json, "vpn");
    if (ssid && pass && key && cJSON_IsBool(vpn))
        err = test_credentials(ssid, pass, key, cJSON_IsTrue(vpn));
    cJSON_Delete(json);
    if (err != ESP_OK)
        return httpd_resp_send_err(req,HTTPD_400_BAD_REQUEST,
            err == ESP_ERR_TIMEOUT ? "No IP address. Check the Wi-Fi credentials and DHCP." : "Check Wi-Fi settings and the Tailscale key if enabled.");
    struct in_addr lan = {.s_addr = htonl(station_address())};
    char result[180];
    snprintf(result, sizeof(result), "Wi-Fi connected. Local IP: %s. Restarting; reconnect to the setup hotspot to see the console address.", inet_ntoa(lan));
    err = httpd_resp_sendstr(req, result);
    restart_soon();
    return err;
}

static esp_err_t scan_wifi(httpd_req_t *req) {
    if (strcmp(network_status(), "setup") || esp_wifi_scan_start(NULL, true) != ESP_OK)
        return httpd_resp_send_err(req, HTTPD_400_BAD_REQUEST, "Scan unavailable. Enter the network name manually.");
    uint16_t count = 20;
    wifi_ap_record_t *records = calloc(count, sizeof(*records));
    if (!records) {
        esp_wifi_clear_ap_list();
        return httpd_resp_send_500(req);
    }
    esp_err_t err = esp_wifi_scan_get_ap_records(&count, records);
    cJSON *list = cJSON_CreateArray();
    for (int i = 0; err == ESP_OK && list && i < count; i++) {
        if (records[i].ssid[0]) cJSON_AddItemToArray(list, cJSON_CreateString((char *)records[i].ssid));
    }
    free(records);
    char *out = list ? cJSON_PrintUnformatted(list) : NULL;
    cJSON_Delete(list);
    if (!out) return httpd_resp_send_500(req);
    httpd_resp_set_type(req,"application/json");
    err = httpd_resp_sendstr(req,out);
    free(out);
    return err;
}
static esp_err_t route(httpd_req_t *req) {
    uint32_t ip = local_address(httpd_req_to_sockfd(req));
    bool ap = setup_active() && ip == 0xc0a80401;
    if (!ap && (!ip || (ip != tunnel_address() && (vpn_enabled() || ip != station_address())))) return httpd_resp_send_404(req);
    char path[32];
    size_t n = strcspn(req->uri,"?");
    if (n >= sizeof(path)) return httpd_resp_send_404(req);
    memcpy(path,req->uri,n);
    path[n] = 0;
    httpd_resp_set_hdr(req,"Cache-Control","no-store");
    httpd_resp_set_hdr(req,"X-Frame-Options","DENY");
    if (req->method == HTTP_GET) {
        if (!strcmp(path,"/")) {
            if (ap) return SEND(setup,"text/html; charset=utf-8");
            return SEND(terminal,"text/html; charset=utf-8");
        }
        if (!strcmp(path,"/style.css")) return SEND(style,"text/css");
        if (!ap && !strcmp(path,"/xterm.js")) {
            httpd_resp_set_hdr(req,"Content-Encoding","gzip");
            return SEND(xterm,"text/javascript");
        }
        if (!ap && !strcmp(path,"/xterm.css")) {
            httpd_resp_set_hdr(req,"Content-Encoding","gzip");
            return SEND(xcss,"text/css");
        }
        if (ap && !strcmp(path,"/status")) {
            char json[128];
            uint32_t vpn = vpn_enabled() ? tunnel_address() : station_address();
            struct in_addr address = {.s_addr = htonl(vpn)};
            snprintf(json,sizeof(json),"{\"state\":\"%s\",\"ip\":\"%s\",\"vpn\":%s}",network_status(),inet_ntoa(address), vpn_enabled() ? "true" : "false");
            httpd_resp_set_type(req,"application/json");
            return httpd_resp_sendstr(req,json);
        }
    }
    char credential[65];
    if (httpd_req_get_hdr_value_str(req,"X-Device-Key",credential,sizeof(credential)) != ESP_OK ||
        strcmp(credential, ap ? SETUP_PASSWORD : device_password)) return httpd_resp_send_err(req,HTTPD_401_UNAUTHORIZED,"Incorrect password.");
    char body[1153] = {0};
    if (req->content_len >= sizeof(body)) return httpd_resp_send_err(req,HTTPD_413_CONTENT_TOO_LARGE,"Request too large.");
    size_t used = 0;
    while (used < req->content_len) {
        int got = httpd_req_recv(req,body+used,req->content_len-used);
        if (got <= 0) return ESP_FAIL;
        used += got;
    }
    if (ap && !strcmp(path,"/scan") && req->method == HTTP_GET) return scan_wifi(req);
    if (!ap && !strcmp(path, "/password") && req->method == HTTP_POST) {
        if (used < 8 || used >= sizeof(device_password))
            return httpd_resp_send_err(req, HTTPD_400_BAD_REQUEST, "Use 8 to 64 printable ASCII characters.");
        for (size_t i = 0; i < used; i++)
            if ((unsigned char)body[i] < 33 || (unsigned char)body[i] > 126)
                return httpd_resp_send_err(req, HTTPD_400_BAD_REQUEST, "Use printable ASCII characters without spaces.");
        if (nvs_set_str(store, "web_password", body) != ESP_OK || nvs_commit(store) != ESP_OK)
            return httpd_resp_send_500(req);
        strlcpy(device_password, body, sizeof(device_password));
        return httpd_resp_sendstr(req, "Password changed.");
    }
    if (!ap) return serial_http(req,path,body,used);
    if (!strcmp(path,"/setup") && req->method == HTTP_POST) return provision(req,body);
    return httpd_resp_send_404(req);
}

void server_start(void) {
    httpd_config_t cfg = HTTPD_DEFAULT_CONFIG();
    cfg.uri_match_fn = httpd_uri_match_wildcard;
    cfg.stack_size = 9216;
    cfg.lru_purge_enable = true;
    httpd_handle_t server;
    ESP_ERROR_CHECK(httpd_start(&server,&cfg));
    httpd_uri_t all = {.uri="/*", .handler=route, .method=HTTP_GET};
    ESP_ERROR_CHECK(httpd_register_uri_handler(server,&all));
    all.method = HTTP_POST;
    ESP_ERROR_CHECK(httpd_register_uri_handler(server,&all));
}
