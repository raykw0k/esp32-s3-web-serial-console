#include "console.h"
#include <stdatomic.h>
#include <string.h>
#include "driver/gpio.h"
#include "esp_log.h"
#include "esp_mac.h"
#include "esp_random.h"
#include "lwip/inet.h"
#include "esp_system.h"
#include "freertos/FreeRTOS.h"
#include "freertos/event_groups.h"
#include "microlink.h"
#include "nvs_flash.h"

typedef struct {
    char ssid[33], password[65], key[160];
} credentials_t;
enum { NORMAL, EDIT, JOINING };
static credentials_t saved;
static uint8_t mode;
static atomic_bool ap_enabled;
static atomic_uint vpn_ip, station_ip;
uint32_t station_address(void) { return atomic_load(&station_ip); }
bool vpn_enabled(void) { return saved.key[0] != 0; }
static EventGroupHandle_t wifi_events;
#define GOT_IP BIT0
#define DISCONNECTED BIT1
nvs_handle_t store;
char device_name[32], device_password[65];

bool setup_active(void) { return atomic_load(&ap_enabled); }
uint32_t tunnel_address(void) { return atomic_load(&vpn_ip); }

const char *network_status(void) {
    if (mode == EDIT) return "setup";
    if (!(xEventGroupGetBits(wifi_events) & GOT_IP)) return "wifi";
    return !vpn_enabled() || tunnel_address() ? "online" : "tailscale";
}

static void wifi_event(void *arg, esp_event_base_t base, int32_t id, void *data) {
    if (base == IP_EVENT && id == IP_EVENT_STA_GOT_IP) {
        atomic_store(&station_ip, ntohl(((ip_event_got_ip_t *)data)->ip_info.ip.addr));
        xEventGroupSetBits(wifi_events, GOT_IP);
    } else if (base == WIFI_EVENT && id == WIFI_EVENT_STA_DISCONNECTED) {
        atomic_store(&station_ip, 0);
        xEventGroupClearBits(wifi_events, GOT_IP);
        xEventGroupSetBits(wifi_events, DISCONNECTED);
        if (mode != EDIT) esp_wifi_connect();
    }
}

static esp_err_t connect_station(const char *ssid, const char *pass) {
    wifi_config_t config = {0};
    memcpy(config.sta.ssid, ssid, strlen(ssid));
    memcpy(config.sta.password, pass, strlen(pass));
    config.sta.failure_retry_cnt = 2;
    esp_err_t err = esp_wifi_set_config(WIFI_IF_STA, &config);
    return err == ESP_OK ? esp_wifi_connect() : err;
}

static void delayed_restart(void *unused) {
    vTaskDelay(pdMS_TO_TICKS(800));
    esp_restart();
}
void restart_soon(void) { xTaskCreate(delayed_restart, "restart", 2048, NULL, 3, NULL); }

esp_err_t test_credentials(const char *ssid, const char *pass, const char *key, bool vpn) {
    if (mode != EDIT || !ssid[0] || strlen(ssid) > 32 || strlen(pass) > 63 ||
        strlen(key) >= sizeof(saved.key) || (vpn && !key[0] && !saved.key[0])) return ESP_ERR_INVALID_ARG;
    xEventGroupClearBits(wifi_events, GOT_IP | DISCONNECTED);
    esp_err_t err = connect_station(ssid, pass);
    if (err != ESP_OK) return err;
    EventBits_t result = xEventGroupWaitBits(wifi_events, GOT_IP | DISCONNECTED,
                                              pdFALSE, pdFALSE, pdMS_TO_TICKS(18000));
    if (!(result & GOT_IP)) {
        esp_wifi_disconnect();
        return ESP_ERR_TIMEOUT;
    }
    credentials_t next = {0};
    strlcpy(next.ssid, ssid, sizeof(next.ssid));
    strlcpy(next.password, pass, sizeof(next.password));
    if (vpn) strlcpy(next.key, key[0] ? key : saved.key, sizeof(next.key));
    err = nvs_set_blob(store, "network", &next, sizeof(next));
    if (err == ESP_OK) err = nvs_set_u8(store, "mode", JOINING);
    if (err == ESP_OK) err = nvs_commit(store);
    return err;
}

static void vpn_state(microlink_t *ml, microlink_state_t state, void *unused) {
    atomic_store(&vpn_ip, state == ML_STATE_CONNECTED ? microlink_get_vpn_ip(ml) : 0);
}
static void run_vpn(void *unused) {
    xEventGroupWaitBits(wifi_events, GOT_IP, pdFALSE, pdFALSE, portMAX_DELAY);
    microlink_config_t cfg = {
        .auth_key = saved.key, .device_name = device_name,
        .enable_derp = true, .enable_stun = true, .enable_disco = true,
        .max_peers = CONFIG_ML_MAX_PEERS, .wifi_tx_power_dbm = 13
    };
    microlink_t *ml = microlink_init(&cfg);
    if (ml) {
        microlink_set_state_callback(ml, vpn_state, NULL);
        if (microlink_start(ml) != ESP_OK) ESP_LOGE("console", "VPN start failed");
    }
    vTaskDelete(NULL);
}

static void init_wifi(void) {
    esp_netif_create_default_wifi_sta();
    esp_netif_create_default_wifi_ap();
    wifi_init_config_t cfg = WIFI_INIT_CONFIG_DEFAULT();
    ESP_ERROR_CHECK(esp_wifi_init(&cfg));
    ESP_ERROR_CHECK(esp_wifi_set_storage(WIFI_STORAGE_RAM));
    ESP_ERROR_CHECK(esp_event_handler_register(WIFI_EVENT, WIFI_EVENT_STA_DISCONNECTED, wifi_event, NULL));
    ESP_ERROR_CHECK(esp_event_handler_register(IP_EVENT, IP_EVENT_STA_GOT_IP, wifi_event, NULL));
    atomic_store(&ap_enabled, mode != NORMAL);
    ESP_ERROR_CHECK(esp_wifi_set_mode(setup_active() ? WIFI_MODE_APSTA : WIFI_MODE_STA));
    if (setup_active()) {
        wifi_config_t ap = {.ap = {.authmode = WIFI_AUTH_WPA2_PSK, .max_connection = 2, .channel = 1}};
        strlcpy((char *)ap.ap.ssid, SETUP_SSID, sizeof(ap.ap.ssid));
        strlcpy((char *)ap.ap.password, SETUP_PASSWORD, sizeof(ap.ap.password));
        ESP_ERROR_CHECK(esp_wifi_set_config(WIFI_IF_AP, &ap));
        printf("Setup Wi-Fi: %s\n", ap.ap.ssid);
    }
    ESP_ERROR_CHECK(esp_wifi_start());
    ESP_ERROR_CHECK(esp_wifi_set_ps(WIFI_PS_NONE));
}

void app_main(void) {
    ESP_ERROR_CHECK(nvs_flash_init());
    ESP_ERROR_CHECK(nvs_open("console", NVS_READWRITE, &store));
    size_t len = sizeof(saved);
    nvs_get_u8(store, "mode", &mode);
    if (nvs_get_blob(store, "network", &saved, &len) != ESP_OK || len != sizeof(saved)) mode = EDIT;
    uint8_t mac[6];
    ESP_ERROR_CHECK(esp_read_mac(mac, ESP_MAC_WIFI_STA));
    snprintf(device_name, sizeof(device_name), "console-%02x%02x%02x", mac[3], mac[4], mac[5]);
    wifi_events = xEventGroupCreate();
    ESP_ERROR_CHECK(esp_netif_init());
    ESP_ERROR_CHECK(esp_event_loop_create_default());
    len = sizeof(device_password);
    esp_err_t pw_err = nvs_get_str(store, "web_password", device_password, &len);
    if (pw_err == ESP_ERR_NVS_NOT_FOUND) strlcpy(device_password, SETUP_PASSWORD, sizeof(device_password));
    else ESP_ERROR_CHECK(pw_err);
    init_wifi();
    serial_init();
    server_start();
    if (mode != EDIT) {
        ESP_ERROR_CHECK(connect_station(saved.ssid, saved.password));
        if (vpn_enabled()) xTaskCreate(run_vpn, "vpn-start", 8192, NULL, 4, NULL);
    }
    gpio_config_t button = {.pin_bit_mask = 1ULL << GPIO_NUM_0, .mode = GPIO_MODE_INPUT, .pull_up_en = 1};
    ESP_ERROR_CHECK(gpio_config(&button));
    int pressed = 0, online = 0;
    for (;;) {
        vTaskDelay(pdMS_TO_TICKS(100));
        pressed = gpio_get_level(GPIO_NUM_0) ? 0 : pressed + 1;
        if (pressed == 40) {
            ESP_ERROR_CHECK(nvs_set_u8(store, "mode", EDIT));
            ESP_ERROR_CHECK(nvs_commit(store));
            while (!gpio_get_level(GPIO_NUM_0)) vTaskDelay(pdMS_TO_TICKS(50));
            esp_restart();
        }
        if (mode == JOINING && setup_active()) {
            online = (vpn_enabled() ? tunnel_address() : station_address()) ? online + 1 : 0;
            if (online == 450) {
                ESP_ERROR_CHECK(nvs_set_u8(store, "mode", NORMAL));
                ESP_ERROR_CHECK(nvs_commit(store));
                atomic_store(&ap_enabled, false);
                ESP_ERROR_CHECK(esp_wifi_set_mode(WIFI_MODE_STA));
            }
        }
    }
}
