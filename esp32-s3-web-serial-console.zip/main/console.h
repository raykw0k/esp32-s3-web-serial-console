#pragma once
#define SETUP_SSID "raykwok-rmt-console"
#define SETUP_PASSWORD "12345678"
#include "esp_http_server.h"
#include "nvs.h"
#include "esp_wifi.h"
#include "cJSON.h"
extern nvs_handle_t store;
extern char device_name[32], device_password[65];
uint32_t station_address(void);
bool vpn_enabled(void);
bool setup_active(void);
uint32_t tunnel_address(void); // IPv4, host byte order
const char *network_status(void);
esp_err_t test_credentials(const char *ssid, const char *pass, const char *key, bool vpn);
void restart_soon(void);
void serial_init(void);
void server_start(void);
esp_err_t serial_http(httpd_req_t *req, const char *path, char *body, size_t len);
