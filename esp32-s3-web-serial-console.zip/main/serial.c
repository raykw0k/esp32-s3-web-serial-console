#include "console.h"
#include <string.h>
#include <stdlib.h>
#include <inttypes.h>
#include "driver/uart.h"
#include "esp_heap_caps.h"
#include "freertos/FreeRTOS.h"
#include "freertos/semphr.h"

#define PORT UART_NUM_1
#define HISTORY 32768
typedef struct { int baud, bits, parity, stop; } settings_t;
static settings_t active = {9600, 8, 0, 1};
static uint8_t *history;
static uint64_t total;
static SemaphoreHandle_t lock;
static bool valid(settings_t s) {
    return s.baud >= 300 && s.baud <= 921600 && s.bits >= 5 && s.bits <= 8 &&
           s.parity >= 0 && s.parity <= 2 && s.stop >= 1 && s.stop <= 3;
}
static esp_err_t configure(settings_t s) {
    const uart_parity_t parity[] = {UART_PARITY_DISABLE, UART_PARITY_ODD, UART_PARITY_EVEN};
    const uart_stop_bits_t stop[] = {UART_STOP_BITS_1, UART_STOP_BITS_2, UART_STOP_BITS_1_5};
    uart_config_t cfg = {.baud_rate = s.baud, .data_bits = UART_DATA_5_BITS + s.bits - 5,
        .parity = parity[s.parity], .stop_bits = stop[s.stop-1], .flow_ctrl = UART_HW_FLOWCTRL_DISABLE,
        .source_clk = UART_SCLK_DEFAULT};
    return uart_param_config(PORT, &cfg);
}
static void capture(void *unused) {
    uint8_t buf[512];
    for (;;) {
        int n = uart_read_bytes(PORT, buf, sizeof(buf), pdMS_TO_TICKS(20));
        if (n <= 0) continue;
        xSemaphoreTake(lock, portMAX_DELAY);
        for (int i = 0; i < n; i++) history[total++ % HISTORY] = buf[i];
        xSemaphoreGive(lock);
    }
}
void serial_init(void) {
    size_t len = sizeof(active);
    settings_t saved;
    if (nvs_get_blob(store, "uart", &saved, &len) == ESP_OK && len == sizeof(saved) && valid(saved)) active = saved;
    lock = xSemaphoreCreateMutex();
    history = heap_caps_malloc(HISTORY, MALLOC_CAP_SPIRAM | MALLOC_CAP_8BIT);
    assert(history && lock);
    ESP_ERROR_CHECK(uart_driver_install(PORT, 8192, 2048, 0, NULL, 0));
    ESP_ERROR_CHECK(configure(active));
    ESP_ERROR_CHECK(uart_set_pin(PORT, 17, 18, UART_PIN_NO_CHANGE, UART_PIN_NO_CHANGE));
    xTaskCreate(capture, "uart-rx", 3072, NULL, 8, NULL);
}

static esp_err_t read_output(httpd_req_t *req) {
    char value[32], query[64];
    uint64_t pos = 0;
    if (httpd_req_get_url_query_str(req, query, sizeof(query)) == ESP_OK &&
        httpd_query_key_value(query, "pos", value, sizeof(value)) == ESP_OK) pos = strtoull(value, NULL, 10);
    uint8_t *buf = malloc(4096);
    if (!buf) return httpd_resp_send_500(req);
    xSemaphoreTake(lock, portMAX_DELAY);
    uint64_t oldest = total > HISTORY ? total - HISTORY : 0;
    bool lost = pos < oldest || pos > total;
    if (lost) pos = oldest;
    size_t n = total - pos > 4096 ? 4096 : total - pos;
    for (size_t i = 0; i < n; i++) buf[i] = history[(pos+i) % HISTORY];
    xSemaphoreGive(lock);
    snprintf(value, sizeof(value), "%" PRIu64, pos+n);
    httpd_resp_set_hdr(req, "X-Next", value);
    if (lost) httpd_resp_set_hdr(req, "X-Gap", "1");
    httpd_resp_set_type(req, "application/octet-stream");
    esp_err_t err = httpd_resp_send(req, (char *)buf, n);
    free(buf);
    return err;
}
static int number(cJSON *obj, const char *name) {
    cJSON *item = cJSON_GetObjectItemCaseSensitive(obj, name);
    return cJSON_IsNumber(item) && item->valuedouble == item->valueint ? item->valueint : -1;
}
esp_err_t serial_http(httpd_req_t *req, const char *path, char *body, size_t len) {
    if (!strcmp(path,"/rx") && req->method == HTTP_GET) return read_output(req);
    if (!strcmp(path,"/tx") && req->method == HTTP_POST) {
        if (uart_write_bytes(PORT, body, len) != len) return httpd_resp_send_500(req);
        return httpd_resp_sendstr(req, "ok");
    }
    if (strcmp(path,"/uart")) return httpd_resp_send_404(req);
    if (req->method == HTTP_POST) {
        cJSON *j = cJSON_Parse(body);
        settings_t next = {number(j,"baud"), number(j,"bits"), number(j,"parity"), number(j,"stop")};
        cJSON_Delete(j);
        if (!valid(next)) return httpd_resp_send_err(req, HTTPD_400_BAD_REQUEST, "Invalid serial settings.");
        if (uart_wait_tx_done(PORT, pdMS_TO_TICKS(1500)) != ESP_OK)
            return httpd_resp_send_err(req, HTTPD_400_BAD_REQUEST, "Serial port busy. Try again.");
        if (configure(next) != ESP_OK || nvs_set_blob(store,"uart",&next,sizeof(next)) != ESP_OK ||
            nvs_commit(store) != ESP_OK) {
            configure(active);
            return httpd_resp_send_500(req);
        }
        active = next;
    }
    char json[100];
    snprintf(json,sizeof(json),"{\"baud\":%d,\"bits\":%d,\"parity\":%d,\"stop\":%d}",
             active.baud,active.bits,active.parity,active.stop);
    httpd_resp_set_type(req, "application/json");
    return httpd_resp_sendstr(req,json);
}
