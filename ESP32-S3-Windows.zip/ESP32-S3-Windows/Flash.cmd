@echo off
setlocal
cd /d "%~dp0" || exit /b 1
echo Factory install for ESP32-S3 N16R8. This clears saved Wi-Fi, Tailscale and console settings.
choice /C YN /N /M "Continue with factory installation? [Y/N] "
if errorlevel 2 exit /b 0
if not errorlevel 1 exit /b 1
"tools\espflash.exe" write-bin --skip-update-check --chip esp32s3 --confirm-port 0x0 firmware.bin
if errorlevel 1 goto failed
echo Done. Join raykwok-rmt-console to configure the board.
pause
exit /b 0
:failed
echo Flash failed. See README.txt and retry.
pause
exit /b 1
